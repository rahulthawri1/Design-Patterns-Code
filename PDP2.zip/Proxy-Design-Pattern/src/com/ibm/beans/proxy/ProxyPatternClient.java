package com.ibm.beans.proxy;

import com.ibm.beans.OfficeInternetAccess;
import com.ibm.beans.impl.ProxyInternetAccess;

/**
 * @author rahuldigambart
 *
 * So here we are checking the Internet access on the basic of employee name
 * who has the Real Internet access granted.
 *
 */
public class ProxyPatternClient {
	
	public static void main(String[] args) 
	{
		OfficeInternetAccess access = new ProxyInternetAccess("Rahul Thawri");
		
		access.grantInternetAccess();
	}


}
