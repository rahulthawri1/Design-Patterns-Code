package com.ibm.pattern.cldp.invoke;

import com.ibm.pattern.cldp.command.command;
import com.ibm.pattern.cldp.receiver.Television;

/**
 * @author rahuldigambart
 *
 * Now remote control is the invoker who can issue several commands
 * and command triggers an action on the receiver who knows
 * how to handle that action.
 */
public class RemoteControl {
	public void invoke(command command)
	{
		command.execute();
	}

}
