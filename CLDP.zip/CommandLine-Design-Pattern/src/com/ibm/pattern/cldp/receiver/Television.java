package com.ibm.pattern.cldp.receiver;

/**
 * @author rahuldigambart
 *
 * Receiver (he knows how to perform the action)
 */
public class Television {
public void on()
{
	System.out.println("Television switcher On...!!!");
}
public void off()
{
	System.out.println("Television turning Off...!!!");
}
}
