package com.ibm.pattern.cldp.client;

import com.ibm.pattern.cldp.command.PowerOff;
import com.ibm.pattern.cldp.command.PowerOn;
import com.ibm.pattern.cldp.command.command;
import com.ibm.pattern.cldp.invoke.RemoteControl;
import com.ibm.pattern.cldp.receiver.Television;

/**
 * @author rahuldigambart
 *
 *Finally client is the person who issues a command on the invoker.
 */
public class Client {
	public static void main(String[] args) {
		// invoker
		RemoteControl control = new RemoteControl();
		// receiver
		Television television = new Television();
		// command setup with receiver
		PowerOn powerOn = new PowerOn(television);
		control.invoke(powerOn);
		// command setup with receiver
		/*
		 * PowerOff powerOff = new PowerOff(television); control.invoke(powerOff);
		 */
		
	}
}
