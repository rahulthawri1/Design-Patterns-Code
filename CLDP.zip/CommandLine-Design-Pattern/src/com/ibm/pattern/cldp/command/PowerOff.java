package com.ibm.pattern.cldp.command;

import com.ibm.pattern.cldp.receiver.Television;

/**
 * @author rahuldigambart
 * 
 * Implementing this interface we have two commands, PowerOn and PowerOff
 * shown below... in the below Television is the receiver on who the command
 * is issuing the action.
 */
//command , encapsulated with receiver to perform action
public class PowerOff implements command{
// receiver on who command performs the action
private Television television;

public PowerOff(Television television) {
	super();
	this.television = television;
}

@Override
public void execute() {
	television.off();
	
}
	

}
