package com.ibm.pattern.cldp.command;

/**
 * @author rahuldigambart
 *
 *Here is the code snippet explaining the same as we discussed.
 *the interface acts as a core contract for commands.
 * 
 */
public interface command {
void execute();
}
