package com.ibm.pattern.cldp.command;

import com.ibm.pattern.cldp.receiver.Television;

/**
 * @author rahuldigambart
 *
 *Implementing this interface we have two commands, PowerOn and PowerOff shown below
 */
//command , encapsulated with receiver to perform action
public class PowerOn implements command{
	// receiver on who command performs the action
	private Television television;

	public PowerOn(Television television) {
		super();
		this.television = television;
	}

	@Override
	public void execute() {
		television.on();
		
	}

}
