package com.ibm.stdp.pattern.beans;

import java.io.Serializable;

/**
 * @author rahuldigambart
 *
 *So, how to avoid creating more than one objects of the singleton class
 *even we serialize and de-serialize also. that's where we need to write
 *readRsolve() method as part of the singleton class.
 *The de-serialization process will call readResolve() method on a class
 *to read the byte stream to build the object. If we write this method
 *and can return the sane instance of the class, we can avoid creating more than
 *one object even in case of serialization as well.
 *Below is the the piece of code implemented how to fix the problem we discussed 
 *when it comes to serialization and de-serialization process.
 *
 */
public class CurrencyConverter extends AppBase implements Serializable {
// declare a static member of the same class-type in the class
	private static CurrencyConverter object;

//construct is declared as private
	private CurrencyConverter() {

	}

// declare a static method to crate only one instance (static factory method)
	public static CurrencyConverter getObject() {
		if (object == null) {
			object = new CurrencyConverter();
		}
		return object;

	}

	 protected Object readResolve() { return object; }
	
}
