package com.ibm.stdp.pattern.beans;

import java.io.Serializable;

/**
 * @author rahuldigambart
 *
 *         As we have seen in the last example when it comes to static block use
 *         case we don't need the object also it will be instantiated before the
 *         hand. When we serialize and de-serialize a singleton class, the
 *         de-serialization process will creates as many numbers of objects for
 *         singleton class which avoids the rule of singleton.
 */
public class AppBase implements Serializable {

	private static final long serialVersionUID = -2911196125430331201L;

}