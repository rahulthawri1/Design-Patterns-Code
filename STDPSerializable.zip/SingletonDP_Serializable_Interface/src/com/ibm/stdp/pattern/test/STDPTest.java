package com.ibm.stdp.pattern.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.ibm.stdp.pattern.beans.CurrencyConverter;

/**
 * @author rahuldigambart
 * Let's take a look at the below piece of code which is trying to serialize
 * and de-serialize our singleton class.
 */
public class STDPTest {

	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		CurrencyConverter currencyConverter1 = CurrencyConverter.getObject();
		//System.out.println("Serialization process started...!!!"); 
		ObjectOutputStream objectOutputStream = new ObjectOutputStream(
				new FileOutputStream(new File("C:\\Users\\rahuldigambart\\Desktop\\currencyConverter.ser")));
		objectOutputStream.writeObject(currencyConverter1);
		//System.out.println("Serialization process ended...!!!"); 

		CurrencyConverter currencyConverter2 = null;
		//System.out.println("De-Serialization process started...!!!"); 
		ObjectInputStream objectInputStream = new ObjectInputStream(
				new FileInputStream(new File("C:\\Users\\rahuldigambart\\Desktop\\currencyConverter.ser")));
		currencyConverter2 = (CurrencyConverter) objectInputStream.readObject();
		//System.out.println("De-Serialization process ended...!!!"); 
		System.out.println("currencyConverter1 == currencyConverter2 : ?" + (currencyConverter1 == currencyConverter2));
		System.out.println(currencyConverter1 == currencyConverter2);
		System.out.println(currencyConverter1.equals(currencyConverter2));
		System.out.println("Hash-Code:"+currencyConverter1.hashCode());
		System.out.println("Hash-Code:"+currencyConverter2.hashCode());

	}

}
