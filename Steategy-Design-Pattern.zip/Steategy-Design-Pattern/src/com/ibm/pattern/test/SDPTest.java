package com.ibm.pattern.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.ibm.pattern.beans.IMessageProducer;
import com.ibm.pattern.writer.MessageWriter;

public class SDPTest {
	public static void main(String[] args) {
		BeanFactory factory= new XmlBeanFactory(new ClassPathResource("com/ibm/pattern/common/Application-context.xml"));
	    MessageWriter messageWriter =(MessageWriter)factory.getBean("messageWriter");
	     
	    IMessageProducer messageProducer=(IMessageProducer) factory.getBean("htmlMessageProducer",IMessageProducer.class);
	    messageWriter.setMessageProducer(messageProducer);
	     messageWriter.writeMessage("Welcome to Strategy Design Pattrn");	
	}
	
}
