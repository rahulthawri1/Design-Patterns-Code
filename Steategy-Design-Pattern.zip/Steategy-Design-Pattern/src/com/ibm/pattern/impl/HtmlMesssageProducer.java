package com.ibm.pattern.impl;

import com.ibm.pattern.beans.IMessageProducer;

public class HtmlMesssageProducer implements IMessageProducer{

	@Override
	public String convertMessage(String message) {
		// TODO Auto-generated method stub
		return "<html><body>"+message+"</html></body>";
	}

}
