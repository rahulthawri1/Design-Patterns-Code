package com.ibm.pattern.impl;

import com.ibm.pattern.beans.IMessageProducer;

public class PdfMessageProducer implements IMessageProducer{

	@Override
	public String convertMessage(String message) {
		// TODO Auto-generated method stub
		return "<pdf><body>"+message+"</pdf></body>";
	}

}
