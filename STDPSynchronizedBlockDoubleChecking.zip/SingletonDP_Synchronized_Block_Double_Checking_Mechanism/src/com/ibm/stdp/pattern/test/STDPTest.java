package com.ibm.stdp.pattern.test;

import com.ibm.stdp.pattern.beans.Worker;

/**
 * @author rahuldigambart
 *
 */
public class STDPTest {

	public static void main(String[] args) {
		Worker worker=new Worker();
		for(int i=0;i<10;i++)
		{
			Thread thread1=new Thread(worker);
			Thread thread2=new Thread(worker);
			thread1.start();
			thread2.start();
			
		}
	}

}
