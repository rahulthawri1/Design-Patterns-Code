package com.ibm.stdp.pattern.beans;

/**
 * @author rahuldigambart
 *
 * Again we have a problem with the below piece of code, after the first call
 * to the getObject() method, in the calls to the method will check for instance == null
 * check. While doing this check, it acquire the lock to verify the condition
 * which is not required. Acquiring and releasing locks are quite costly and
 * we should avoid as much as we can. To fix this we can have double check
 * for the condition as shown below
 *
 */
public class CurrencyConverter {
	// declare a static member of the same class-type in the class
	private static CurrencyConverter object;
	// construct id declared as private
	private CurrencyConverter() {

	}
	// declare a static method to crate only one instance (static factory method)
	public static CurrencyConverter getObject() {
		// Here Double checking Mechanism...
		if (object == null) {
			// Here synchronized-Block
			synchronized(CurrencyConverter.class) {
				if (object == null) {
					System.out.println("Locked...!!!");
					object = new CurrencyConverter();
				}
			}
			System.out.println("Releasing...!!!");
		}
		return object;
	}
}
