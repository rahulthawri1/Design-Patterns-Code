package com.ibm.pattern.sdp.util;

import java.io.FileInputStream;
import java.util.Properties;

import com.ibm.pattern.sdp.beans.IMessageProducer;
import com.ibm.pattern.sdp.beans.MessageWriter;

/**
 * @author rahuldigambart
 *
 */
public class AppFactory {
public static Object createObject(String l_class) throws Exception, IllegalAccessException, ClassNotFoundException
{
	Properties properties=null;
	String className=null;
	Object object=null;
    properties = new Properties();
	properties.load(new FileInputStream("C:\\Workspace\\GOF\\DesignPattern\\Strategy-Design-Pattern\\src\\com\\ibm\\pattern\\sdp\\common\\App-classes.properties"));
	className = properties.getProperty(l_class);
	Object obj = Class.forName(className).newInstance();
	return obj;
	
	
}


}
