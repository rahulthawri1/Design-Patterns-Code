package com.ibm.pattern.sdp.util;

import com.ibm.pattern.sdp.beans.HtmlMessageProducer;
import com.ibm.pattern.sdp.beans.IMessageProducer;
import com.ibm.pattern.sdp.beans.PdfMessageProducer;

/**
 * @author rahuldigambart
 *
 */
public class MessageProducerFactory {
	public static IMessageProducer createMessageProducer(String type)
	{
		IMessageProducer messageProducer=null;
		
		if(type.equals("html"))
		{
   messageProducer=new HtmlMessageProducer();
}
		else if(type.equals("pdf"))
		{
			messageProducer=new PdfMessageProducer();
		}
		return messageProducer;
		
	}

}
