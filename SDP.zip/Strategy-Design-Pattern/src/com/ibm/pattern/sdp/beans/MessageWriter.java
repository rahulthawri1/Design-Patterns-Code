package com.ibm.pattern.sdp.beans;

/**
 * @author rahuldigambart
 *
 *
 *         We have a MessageWriter class which will write message to the
 *         console. the MessageWriter class will get the message from
 *         MessageProducer class. But we have multiple types of MessageProducers
 *         like HTMLMessageProducer and PDFMessageProducer etc.
 * 
 *         So the MessageWriter will talks to the message producer through an
 *         interface IMessageProducer, which defines a method writeMessage.
 * 
 *         Even you followed the recommended design principles, it has two
 *         problems
 * 
 *         In MessageWriter class inside the writeMessage method if we hardcoded
 *         the concrete class name HTMLMessageProducer while instantiating
 *         messageProducer attribute. If we want to switch between
 *         HTMLMessageProducer to PDFMessageProducer we need to modify the
 *         source code of the MessageWriter.
 * 
 *         MessageWriter to use the service of HTMLMessageProducer it is trying
 *         to create the object of it. If MessageWriter is trying to create the
 *         object of HTMLMessageProducer or PDFMessageProducer, it has to know
 *         the complete instantiation process of creating those. Some classes
 *         can be created out of calling new operator, but some classes should
 *         be created using complex instantiation technic like sometimes ==>
 *         Let's say A want B it has to create B but to create B it is using C
 *         so first create C and then B finally A can use it.
 * 
 * 
 *         This tells unless A instantiate all the dependents that B needs it
 *         can not use, and the same piece of code has to be written by all the
 *         other class which ever want to use B. so code is duplicated across
 *         the logic to create B.
 * 
 *         To avoid the above problems instead of MessagWriter creating the
 *         object of IMessageProducer implementation class, it should
 *         externalize this functionality to someone else, that's where factory
 *         come into picture.
 */
public class MessageWriter {
	private IMessageProducer messageProducer;

	public void writeMessage(String message) {
		// String cMessage=null;
		//IMessageProducer messageProducer=null;
		//messageProducer= new HtmlMessageProducer();
		String cMessage = messageProducer.convertMessage(message);
		System.out.println(cMessage);

	}

	public void setMessageProducer(IMessageProducer messageProducer) {
		this.messageProducer = messageProducer;
	}

}
