package com.ibm.pattern.sdp.beans;

/**
 * @author rahuldigambart
 *
 *         If you know the concept of IOC ==> Spring Inversion of control Let's
 *         try to understand the IOC by taking one example, first let's design
 *         the classes by following strategy design pattern, and then we will
 *         identify the pit-falls in it and will understand how to simplify it
 *         using IOC
 *
 */
public interface IMessageProducer {
	public String convertMessage(String message);

}
