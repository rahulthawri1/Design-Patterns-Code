package com.ibm.pattern.sdp.beans;

/**
 * @author rahuldigambart
 *
 *
 *If you observe carefully the design has followed all the design principles
 *that spring recommends. code fragment for the below classes
 *are as shown below.
 */
public class HtmlMessageProducer implements IMessageProducer{
public String convertMessage(String message)
{
	return "<html><body>"+message+"</html></body>";
	
}
}
