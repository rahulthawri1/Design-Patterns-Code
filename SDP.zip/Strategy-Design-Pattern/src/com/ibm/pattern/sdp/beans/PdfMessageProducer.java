package com.ibm.pattern.sdp.beans;

/**
 * @author rahuldigambart
 *
 */
public class PdfMessageProducer implements IMessageProducer{
	public String convertMessage(String message)
	{
		return "<pdf><body>"+message+"</pdf></body>";
		
	}

}
