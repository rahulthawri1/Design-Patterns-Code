package com.ibm.pattern.sdp.test;

import com.ibm.pattern.sdp.beans.HtmlMessageProducer;
import com.ibm.pattern.sdp.beans.IMessageProducer;
import com.ibm.pattern.sdp.beans.MessageWriter;
import com.ibm.pattern.sdp.util.AppFactory;
import com.ibm.pattern.sdp.util.MessageProducerFactory;

/**
 * @author rahuldigambart
 *
 */
public class SDPTest {

	public static void main(String[] args) throws IllegalAccessException, ClassNotFoundException, Exception {
		// TODO Auto-generated method stub
		MessageWriter messageWriter = null;
		//IMessageProducer messageProducer=null;
		//messageWriter = new MessageWriter();
		IMessageProducer messageProducer = MessageProducerFactory.createMessageProducer("pdf");
		messageWriter = (MessageWriter) AppFactory.createObject("messageWriter.class");
		// messageProducer =
		// (IMessageProducer)AppFactory.createObject("messageProducer.class");
		messageWriter.setMessageProducer(messageProducer);
		messageWriter.writeMessage("Welcome to Strategy Design Pattern");

	}

}
