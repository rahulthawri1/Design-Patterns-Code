package com.ibm.stdp.pattern.test;

import com.ibm.stdp.pattern.beans.CurrencyConverter;

/**
 * @author rahuldigambart
 *
 */
public class STDPTest {

	public static void main(String[] args) throws ClassNotFoundException {
		CurrencyConverter currencyConverter1 = CurrencyConverter.getObject();
		CurrencyConverter currencyConverter2 = CurrencyConverter.getObject();
		//Class.forName("com.ibm.stdp.pattern.beans.CurrencyConverter");
		
		System.out.println("hascode.?"+currencyConverter1.hashCode());
		System.out.println("hascode.?"+currencyConverter2.hashCode());

	}

}
