package com.ibm.stdp.pattern.beans;

/**
 * @author rahuldigambart
 * 
 *         Eager Initialization Mechanism In the below piece of code we are
 *         instantiating the instance on the first call to the getObject()
 *         method. Instead of delaying with the instantiation process till we
 *         can call the method, we can instantiate it eagerly much before when
 *         class is loaded into the memory as shown below.
 * 
 */
public class CurrencyConverter {
	// declare a static member of the same class-type in the class
	private static CurrencyConverter object = new CurrencyConverter();

	// instantiating the instance attribute when the class is loaded
	// construct is declared as private
	private CurrencyConverter() {
		System.out.println("CurrencyConverter() created");
	}

	// declare a static method to crate only one instance (static factory method)
	public static CurrencyConverter getObject() {
		return object;

	}
}
