package com.ibm.stdp.pattern.test;

import com.ibm.stdp.pattern.beans.CurrencyConverter;

/**
 * @author rahuldigambart
 *
 */
public class STDPTest {

	public static void main(String[] args) {
		CurrencyConverter currencyConverter1 = CurrencyConverter.getObject();
		CurrencyConverter currencyConverter2 = CurrencyConverter.getObject();
		System.out.println("Object has been Created");
		System.out.println(currencyConverter1 == currencyConverter2);
		System.out.println(currencyConverter1.equals(currencyConverter2));
		
		
		System.out.println("hascode.?"+currencyConverter1.hashCode());
		System.out.println("hascode.?"+currencyConverter2.hashCode());
	}

}
