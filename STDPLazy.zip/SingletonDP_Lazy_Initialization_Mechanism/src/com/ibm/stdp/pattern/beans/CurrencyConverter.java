package com.ibm.stdp.pattern.beans;

/**
 * @author rahuldigambart
 *
 *         Lazy Initialization Mechanism In most of the cases it is recommended
 *         to delay the instantiation process until the object is needed. To
 *         achieve this we can delay the creation process till the first call
 *         the getObject() method. But the problem with this is in a
 *         multi-threaded environment when more than one thread are executing at
 *         the same-time, it might end-up in creating more then once instances
 *         of the class
 */
public class CurrencyConverter {
	// declare a static member of the same class-type in the class
	private static CurrencyConverter object;

	// construct id declared as private
	private CurrencyConverter() {

	}

	// declare a static method to crate only one instance (static factory method)
	public static CurrencyConverter getObject() {
		if (object == null) {
			object = new CurrencyConverter();
		}
		return object;

	}
}
