package com.ibm.pattern.test;

import com.ibm.pattern.beans.Pizza;
import com.ibm.pattern.store.PizzaStore;

/**
 * @author rahuldigambart
 *
 */
public class FDPTest {
public static void main(String[] args) {
	PizzaStore pizzaStore = new PizzaStore();
	Pizza pizza = pizzaStore.orderPizza("chicken");
	System.out.println("Wow so Yummy Eating Chicken Pizza ...");
}
}
