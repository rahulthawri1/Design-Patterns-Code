package com.ibm.pattern.impl;

import com.ibm.pattern.beans.Pizza;

/**
 * @author rahuldigambart
 *
 *         In the shop we sell various types of pizza's like
 *         CheesePizza,SpicyPizza and PaneerPizza etc. So we have several
 *         sub-classes from Pizza class to sell different types of pizza as
 *         shown below.
 */
public class SpicyPizza implements Pizza {

	@Override
	public void prepare() {
		// TODO Auto-generated method stub
		System.out.println("Preparing Spicy Pizza");
	}

	@Override
	public void bake() {
		// TODO Auto-generated method stub
		System.out.println("Baking Spicy Pizza");
	}

	@Override
	public void cut() {
		// TODO Auto-generated method stub
		System.out.println("Cutting Spicy Pizza");
	}

	@Override
	public void box() {
		// TODO Auto-generated method stub
		System.out.println("Packing Spicy Pizza");
	}
	
	

}
