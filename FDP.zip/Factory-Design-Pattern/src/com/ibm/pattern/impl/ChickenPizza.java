package com.ibm.pattern.impl;

import com.ibm.pattern.beans.Pizza;

public class ChickenPizza implements Pizza{

	@Override
	public void prepare() {
		// TODO Auto-generated method stub
		System.out.println("Preparing Chicken Pizza");
	}

	@Override
	public void bake() {
		// TODO Auto-generated method stub
		System.out.println("Baking Chicken Pizza");
	}

	@Override
	public void cut() {
		// TODO Auto-generated method stub
		System.out.println("Cutting Chicken Pizza");
	}

	@Override
	public void box() {
		// TODO Auto-generated method stub
		System.out.println("Packing Chicken Pizza");
	}

}
