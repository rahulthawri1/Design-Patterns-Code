package com.ibm.pattern.store;

import com.ibm.pattern.beans.Pizza;
import com.ibm.pattern.factory.PizzaFactory;

/**
 * @author rahuldigambart
 *
 *         Now in the PizzaStore class if someone orders a Pizza we need to
 *         check which type of pizza and needs to create it as shown below.
 *
 */
public class PizzaStore {
	public Pizza orderPizza(String type) {
		Pizza pizza = null;
		pizza=PizzaFactory.orderPizza(type);
		pizza.prepare();
		pizza.bake();
		pizza.cut();
		pizza.box();
		return pizza;
	}
}
