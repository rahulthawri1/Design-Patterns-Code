package com.ibm.stdp.test;

import com.ibm.stdp.pattern.CurrencyConverter;

public class STDPTest {

	public static void main(String[] args) throws ClassNotFoundException {
		CurrencyConverter currencyConverter1 = CurrencyConverter.getObject();
		CurrencyConverter currencyConverter2 = CurrencyConverter.getObject();
		System.out.println("currencyConverter1==currencyConverter2:?"
				+ (currencyConverter1 == currencyConverter2));
		//Class.forName("com.stdp.pattern.CurrencyConverter");
	}

}
