package com.ibm.stdp.pattern;

/**
 * @author rahuldigambart
 *
 * If you have idea around static blocks concept in java, we can use the same
 * concept to instantiate the singleton class as shown below.
 * But the problem with this code is even we don't need the object also
 * it will be instantiated before the hand.
 * It seems like with the below ways we understood the best possible ways
 * of creating a singleton class.
 * Do you see any drawbacks in the below piece of code?
 */
public class CurrencyConverter {
	// declare a static member of the same class-type in the class
	private static CurrencyConverter object;
	// static block execute only once when the class has loaded
	static {
		object = new CurrencyConverter();
	}
    //construct is declared as private
	private CurrencyConverter() {
		System.out.println("CurrencyConverter Created:");
	}
    // declare a static method to crate only once instance 
	// (static factory method)
	public static CurrencyConverter getObject() {
		return object;

	}
}
