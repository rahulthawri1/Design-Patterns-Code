package com.ibm.beans;

/**
 * @author rahuldigambart
 * 
 * Let's try to understand the Proxy design pattern
 * Here we have a interface OfficeInternetAccess in it
 * we do have a method grantInternetAccess() declared shown below.
 * 
 */
public interface OfficeInternetAccess {
	
	public void grantInternetAccess();

}
