package com.ibm.beans.impl;

import com.ibm.beans.OfficeInternetAccess;

/**
 * @author rahuldigambart
 * So here we have a ProxyInternetAccess class in it
 * we do have method grantInternetAccess() where we are checking
 * the grant access based on employee name on which we are maintaining 
 * the job level too. whose job level is below 5 for them we are not
 * providing the Real Internet Access where as whose job level is
 * more than 4 for them we providing the Real Internet access.
 * No Internet access granted. if job level is below 5
 */
public class ProxyInternetAccess implements OfficeInternetAccess {

	private String employeeName;

	private RealInternetAccess realaccess;

	public ProxyInternetAccess(String employeeName) {
		this.employeeName = employeeName;
	}

	@Override
	public void grantInternetAccess() {
		if (getRole(employeeName) > 4) {
			realaccess = new RealInternetAccess(employeeName);
			realaccess.grantInternetAccess();
		} else {
			System.out.println("No Internet access granted. Your job level is below 5");
		}

	}

	public int getRole(String emplName) {
		// Check role from the database based on Name and designation
		// return job level or job designation.
		// return 5; now change the job level
		return 5;
	}

}
