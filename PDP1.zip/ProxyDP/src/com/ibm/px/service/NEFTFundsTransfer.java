package com.ibm.px.service;

import java.util.UUID;

/**
 * @author rahuldigambart
 *
 */
public class NEFTFundsTransfer implements FundsTransfer {
	@Override
	public String transfer(String fromAccount, String toAccount, float amount) {
		System.out.println("Transfer Funds Through NEFT Channel");
		return UUID.randomUUID().toString();
	}

}
