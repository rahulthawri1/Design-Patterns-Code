package com.ibm.px.service;

import java.util.UUID;

/**
 * @author rahuldigambart
 *
 */
public class DirectFundsTransfer implements FundsTransfer {
	@Override
	public String transfer(String fromAccount, String toAccount, float amount) {
		System.out.println("transfering funds directly");
		return UUID.randomUUID().toString();
	}

}
