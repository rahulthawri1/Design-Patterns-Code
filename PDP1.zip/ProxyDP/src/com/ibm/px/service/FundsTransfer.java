package com.ibm.px.service;

/**
 * @author rahuldigambart
 *
 */
public interface FundsTransfer {
	String transfer(String fromAccount, String toAccount, float amount);
}
