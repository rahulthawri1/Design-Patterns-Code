package com.ibm.px.factory;

import com.ibm.px.proxy.MobileSecuredFundsTransferProxy;
import com.ibm.px.proxy.WebSecuredFundsTransferProxy;
import com.ibm.px.service.DirectFundsTransfer;
import com.ibm.px.service.FundsTransfer;
import com.ibm.px.service.NEFTFundsTransfer;

/**
 * @author rahuldigambart
 *
 */
public class FundsTransferFactory {
	public static FundsTransfer getFundsTransfer(String type) {
		FundsTransfer fundsTransfer = null;
		FundsTransfer securityFundsTransfer = null;
		String securityType = null;

		securityType = System.getProperty("securityType");
		if (type.equals("direct")) {
			fundsTransfer = new DirectFundsTransfer();
		} else if (type.equals("neft")) {
			fundsTransfer = new NEFTFundsTransfer();
		}
		securityFundsTransfer = fundsTransfer;
		if (securityType != null) {
			if (securityType.equals("web")) {
				securityFundsTransfer = new WebSecuredFundsTransferProxy(fundsTransfer);
			} else if (securityType.equals("mob")) {
				securityFundsTransfer = new MobileSecuredFundsTransferProxy(fundsTransfer);
			}
		}

		return securityFundsTransfer;
	}
}
