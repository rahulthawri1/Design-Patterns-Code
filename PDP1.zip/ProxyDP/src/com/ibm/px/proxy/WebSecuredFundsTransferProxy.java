package com.ibm.px.proxy;

import com.ibm.px.service.FundsTransfer;

/**
 * @author rahuldigambart
 *
 */
public class WebSecuredFundsTransferProxy implements FundsTransfer {
	private FundsTransfer fundsTransfer;

	public WebSecuredFundsTransferProxy(FundsTransfer fundsTransfer) {
		this.fundsTransfer = fundsTransfer;
	}

	@Override
	public String transfer(String fromAccount, String toAccount, float amount) {
		System.out.println("checking web security");
		return fundsTransfer.transfer(fromAccount, toAccount, amount);
	}

}




