package com.ibm.px.proxy;

import com.ibm.px.service.FundsTransfer;

/**
 * @author rahuldigambart
 *
 */
public class MobileSecuredFundsTransferProxy implements FundsTransfer {
	private FundsTransfer fundsTransfer;

	public MobileSecuredFundsTransferProxy(FundsTransfer fundsTransfer) {
		super();
		this.fundsTransfer = fundsTransfer;
	}

	@Override
	public String transfer(String fromAccount, String toAccount, float amount) {
		System.out.println("mobile security verified");
		return fundsTransfer.transfer(fromAccount, toAccount, amount);
	}

}
