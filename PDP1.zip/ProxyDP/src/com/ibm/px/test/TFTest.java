package com.ibm.px.test;

import com.ibm.px.factory.FundsTransferFactory;
import com.ibm.px.service.FundsTransfer;

/**
 * @author rahuldigambart
 *
 */
public class TFTest {
	public static void main(String[] args) {
		System.setProperty("securityType", "mob");
		FundsTransfer fundsTransfer = FundsTransferFactory.getFundsTransfer("neft");
		fundsTransfer.transfer("12345", "67890", 500.00f);
	}

}
