package com.ibm.pattern;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.io.ClassPathResource;

import com.ibm.pattern.beans.IMessageProducer;
import com.ibm.pattern.writer.MessageWriter;

@SpringBootApplication
public class StrategyDesignPatternApplication {

	public static void main(String[] args) {
		SpringApplication.run(StrategyDesignPatternApplication.class, args);
	}

	
	BeanFactory factory= new XmlBeanFactory(new ClassPathResource("com/ibm/pattern/common/Application-context.xml"));
    MessageWriter messageWriter =(MessageWriter)factory.getBean("messageWriter");
     
    IMessageProducer messageProducer=(IMessageProducer) factory.getBean("htmlMessageProducer",IMessageProducer.class);
    messageWriter.setMessageProducer(messageProducer);
     messageWriter.writeMessage("Welcome to Strategy Design Pattrn");

}
