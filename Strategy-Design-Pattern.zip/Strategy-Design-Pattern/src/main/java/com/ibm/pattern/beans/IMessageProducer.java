package com.ibm.pattern.beans;

public interface IMessageProducer {
String convertMessage(String message);
}
