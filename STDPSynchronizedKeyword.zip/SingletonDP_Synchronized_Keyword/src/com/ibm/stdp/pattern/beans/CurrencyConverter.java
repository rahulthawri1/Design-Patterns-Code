package com.ibm.stdp.pattern.beans;

/**
 * @author rahuldigambart
 * 
 *         In most of the use cases it is recommended to delay the instantiation
 *         process until the object is needed. To achieve this we can delay the
 *         creation process till the first call the getObject() method. But the
 *         problem with this is in a multi-threaded environment when more than
 *         one thread are executing at the same-time, it might end-up in
 *         creating more then once instances of the class. To avoid this we can
 *         even declare that method as synchronized
 */
public class CurrencyConverter {
	// declare a static member of the same class-type in the class
	private static CurrencyConverter object;

	// construct id declared as private
	private CurrencyConverter() {

	}

	// declare a synchronized keyword static method level to crate only one instance
	// when in comes to multi-threaded env (static factory method)
	public synchronized static CurrencyConverter getObject() {
		if (object == null) {
			object = new CurrencyConverter();
		}
		return object;

	}
}
