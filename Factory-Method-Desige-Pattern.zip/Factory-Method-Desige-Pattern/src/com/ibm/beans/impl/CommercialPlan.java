package com.ibm.beans.impl;

import com.ibm.beans.Plan;

class CommercialPlan extends Plan{
	//@override  
    public void getRate(){  
        rate=7.50;              
   }  
}
