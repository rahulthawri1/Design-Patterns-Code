package com.ibm.beans.impl;

import com.ibm.beans.Plan;

class DomesticPlan extends Plan{  
    //@override  
     public void getRate(){  
         rate=3.50;              
    }  
}//end of DomesticPlan class.  
