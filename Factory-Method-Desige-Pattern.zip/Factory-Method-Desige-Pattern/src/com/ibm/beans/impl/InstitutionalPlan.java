package com.ibm.beans.impl;

import com.ibm.beans.Plan;

public class InstitutionalPlan extends Plan{
	 //@override  
    public void getRate(){   
        rate=5.50;  
   } 
}
