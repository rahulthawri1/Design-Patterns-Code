package com.ibm.pattern.common;

import com.ibm.fm.pattern.beans.Car;

/**
 * @author rahuldigambart
 * 
 *         So in the below we want to bring up some quality control and
 *         standardization of assembling a car. create a GlobalWorkshop which
 *         takes care of standardizing the process of assembling the car as
 *         shown below.
 */
public abstract class GlobalWorkshop {
	public Car assembly(String type) {
		Car car = null;
		car = createCar(type);
		// assembling the car
		System.out.println("attach wheels");
		System.out.println("fit seats");
		System.out.println("assemble engine");
		return car;

	}

	protected abstract Car createCar(String type);
}
