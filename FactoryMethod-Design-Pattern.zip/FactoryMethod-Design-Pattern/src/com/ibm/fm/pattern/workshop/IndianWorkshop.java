package com.ibm.fm.pattern.workshop;

import com.ibm.fm.pattern.beans.Car;
import com.ibm.fm.pattern.impl.Mercedes;

/**
 * @author rahuldigambart
 * 
 *For e.g Indian manufacturing unit only manufactures mercedes cars and
 * American manufacturing units only manufactures bugatti cars as shown below
 */
public class IndianWorkshop {
public Car createCar(String type)
{
	Car car = null;
	if(type.equals("mercedes")) {
		car =  new Mercedes(1234, "white");
	}
	// creating and assembly
	System.out.println("assemble engine");
	return car;
	
}
}
