package com.ibm.fm.pattern.workshop;

import com.ibm.fm.pattern.beans.Car;
import com.ibm.fm.pattern.impl.Bugatti;

/**
 * @author rahuldigambart
 *
 *For e.g Indian manufacturing unit only manufactures mercedes cars and
 * American manufacturing units only manufactures bugatti cars as shown below
 * 
 * The problem in the below piece of code is after creating the car, every
 * manufacturing unit is using their own mechanisms of assembling the car.
 * few are attaching wheels,seats and engine. few others forgetting to attach
 * wheels and seats and delivering the car with engine.
 */
public class AmericanWorkshop {
public Car createCar(String type) {
	Car car = null;
	if(type.equals("bugatti")) {
		car = new Bugatti(8976, "red");
	}
	// creating and assembly
	System.out.println("attach wheels");
	System.out.println("fit seats");
	System.out.println("assebmle engine");
	return car;
	
}
}
