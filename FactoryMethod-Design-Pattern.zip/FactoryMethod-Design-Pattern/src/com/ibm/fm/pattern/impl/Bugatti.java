package com.ibm.fm.pattern.impl;

import com.ibm.fm.pattern.beans.Car;

/**
 * @author rahuldigambart
 *
 * These car's will be manufactured across various manufacturing units across glob.
 * Every manufacturing unit may not manufacture all the car models.
 *
 */
public class Bugatti extends Car{

	public Bugatti(int engineNo, String color) {
		super(engineNo, color);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void drive() {
		// TODO Auto-generated method stub
		System.out.println("Driving Bugatti Car");
	}

}
