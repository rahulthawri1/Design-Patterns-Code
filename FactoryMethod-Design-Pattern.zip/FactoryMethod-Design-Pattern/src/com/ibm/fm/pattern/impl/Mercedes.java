package com.ibm.fm.pattern.impl;

import com.ibm.fm.pattern.beans.Car;

public class Mercedes extends Car{

	public Mercedes(int engineNo, String color) {
		super(engineNo, color);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void drive() {
		// TODO Auto-generated method stub
		System.out.println("Driving Mercedes Car");
	}

}
