package com.ibm.fm.pattern.beans;

/**
 * @author rahuldigambart
 *
 * Factory method is used for creating the object for family of related classes
 * with in the hierarchy. Let's consider for example Car company is manufacturing car's.
 *it manufactures several types of car's. it has several manufacturing units
 *in which the cars are being manufactured. 
 * 
 *
 */
public abstract class Car {
	protected int engineNo;
	protected String color;
	// every car has it's own driving style
	public abstract void drive();

	public int getEngineNo() {
		return engineNo;
	}

	public void setEngineNo(int engineNo) {
		this.engineNo = engineNo;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public Car(int engineNo, String color) {
		super();
		this.engineNo = engineNo;
		this.color = color;
	}

	@Override
	public String toString() {
		return "Car [engineNo=" + engineNo + ", color=" + color + ", getEngineNo()=" + getEngineNo() + ", getColor()="
				+ getColor() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	


}
