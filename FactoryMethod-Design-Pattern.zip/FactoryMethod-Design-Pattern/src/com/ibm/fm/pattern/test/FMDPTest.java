package com.ibm.fm.pattern.test;

import com.ibm.fm.pattern.beans.Car;
import com.ibm.fm.pattern.workshop.AmericanWorkshop;
import com.ibm.fm.pattern.workshop.IndianWorkshop;
import com.ibm.pattern.common.GlobalWorkshop;

public class FMDPTest {
	public static void main(String[] args) {
		/*
		 * IndianWorkshop indianWorkshop = new IndianWorkshop(); Car car1 =
		 * indianWorkshop.createCar("bugatti");
		 * System.out.println("Congratulations for Buying Bugatti Car...!!");
		 */
		
		
		AmericanWorkshop americanWorkshop = new AmericanWorkshop();
		Car car2 = americanWorkshop.createCar("mercedes");
		System.out.println("Congratulations for Buying Mercedes Car...!!");
		
	}

}
