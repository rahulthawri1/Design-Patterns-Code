package com.ibm.pattern.factory;

import com.ibm.pattern.beans.Dao;


/**
 * @author rahuldigambart
 *
 */
public abstract class DaoFactory {
public abstract Dao createDao(String type);
}
