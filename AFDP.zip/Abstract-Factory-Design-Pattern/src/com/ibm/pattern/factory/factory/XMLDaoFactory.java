package com.ibm.pattern.factory.factory;

import com.ibm.pattern.beans.Dao;
import com.ibm.pattern.factory.DaoFactory;
import com.ibm.pattern.impl.XMLDeptDao;
import com.ibm.pattern.impl.XMLEmpDao;

/**
 * @author rahuldigambart
 *
 */
public class XMLDaoFactory extends DaoFactory{

	@Override
	public Dao createDao(String type) {
		// TODO Auto-generated method stub
		Dao dao = null;
		if(type.equals("emp")) {
			dao = new XMLEmpDao();
		}else if(type.equals("dept")) {
			dao = new XMLDeptDao();
		}
		return dao;
	}

}
