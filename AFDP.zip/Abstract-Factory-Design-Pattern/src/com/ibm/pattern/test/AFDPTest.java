package com.ibm.pattern.test;

import com.ibm.pattern.beans.Dao;
import com.ibm.pattern.factory.DaoFactory;
import com.ibm.pattern.maker.DaoMaker;

/**
 * @author rahuldigambart
 *
 *
 *For example if an application wants a Dao object it has to do the following
 */
public class AFDPTest {
public static void main(String[] args) {
	DaoFactory daoFactory = null;
	Dao dao = null;
	
	daoFactory = DaoMaker.make("xml");
	dao = daoFactory.createDao("dept");
	dao.save();
}
}
