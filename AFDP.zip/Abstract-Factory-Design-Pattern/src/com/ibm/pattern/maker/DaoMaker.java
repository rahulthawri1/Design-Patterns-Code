package com.ibm.pattern.maker;

import com.ibm.pattern.factory.DaoFactory;
import com.ibm.pattern.factory.factory.DBDaoFactory;
import com.ibm.pattern.factory.factory.XMLDaoFactory;

/**
 * @author rahuldigambart
 *
 *         Now the DaoMaker super factory will takes care of instantiating the
 *         appropriate factory to work with family of Dao's. For any application
 *         it is important to use all Dao's that belongs to same type. So our
 *         DaoMaker enforces this rule by encouraging you to get one type of
 *         factory from which you can Dao's.
 */
public class DaoMaker {
	public static DaoFactory make(String factoryType) {
		DaoFactory daoFactory = null;

		if (factoryType.equals("xml")) {
			daoFactory = new XMLDaoFactory();
		} else if (factoryType.equals("db")) {
			daoFactory = new DBDaoFactory();
		}
		return daoFactory;

	}
}
