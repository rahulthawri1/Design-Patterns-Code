package com.ibm.pattern.beans;

/**
 * @author rahuldigambart
 *
 *         Abstract factory can be treated as a super factory or a factory of
 *         factories. Using design pattern we abstract the creation process of
 *         another class. Using the abstract factory design pattern we abstract
 *         the creation of family of classes.
 * 
 *         To create the objects of Dao's of related types we have created two
 *         different factories. DBDAOFactory and XMLDAOFactory, these factories
 *         takes care of creating the Dao's of their type as shown below
 *
 */
public abstract class Dao {
	public abstract void save();
}
