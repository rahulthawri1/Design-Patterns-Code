package com.ibm.pattern.impl;

import com.ibm.pattern.beans.Dao;

/**
 * @author rahuldigambart
 *
 *         Let's understand it by taking an example, we have several Dao's
 *         classes to persist the data. like EmpDao, DeptDao etc, in turn these
 *         Dao's can persist the data into a database or into an XML file. so we
 *         have now the Dao's as DBEmpDao,DBDeptDao and XMLEmpDao,XMLDeptDao.
 *
 */
public class XMLEmpDao extends Dao {

	@Override
	public void save() {
		// TODO Auto-generated method stub
		System.out.println("Employee has been written to XML file");
	}

}
