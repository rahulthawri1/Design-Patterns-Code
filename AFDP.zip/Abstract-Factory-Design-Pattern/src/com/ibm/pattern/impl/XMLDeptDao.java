package com.ibm.pattern.impl;

import com.ibm.pattern.beans.Dao;

/**
 * @author rahuldigambart
 *
 */
public class XMLDeptDao extends Dao{

	@Override
	public void save() {
		// TODO Auto-generated method stub
		System.out.println("Department has been written to XML file");
	}

}
