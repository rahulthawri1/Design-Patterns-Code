package com.ibm.pattern.impl;

import com.ibm.pattern.beans.Dao;

public class DBEmpDao extends Dao{

	@Override
	public void save() {
		// TODO Auto-generated method stub
		System.out.println("Employee has been written to table");
	}

}
