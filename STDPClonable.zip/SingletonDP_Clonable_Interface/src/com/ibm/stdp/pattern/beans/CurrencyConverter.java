package com.ibm.stdp.pattern.beans;

import java.io.Serializable;

/**
 * @author rahuldigambart
 *
 *For e.g if someone might write a class implementing cloneable interface
 *and caling super.clone() method in it. If your singleton class extends
 *from other class, as the clone() method has been overridden in the base
 *class you can use that method in cloning you object.
 *
 *So to avoid such kind of instances, it is always said to be recommended to override
 * the clone() method and throw exception as shown below.
 *
 */
public class CurrencyConverter extends AppBase implements Cloneable,Serializable{

	private static final long serialVersionUID = 5066215731715219534L;
	private static volatile CurrencyConverter object;

	private CurrencyConverter() {

	}

	public static CurrencyConverter getObject() {
		if (object == null) {
			object = new CurrencyConverter();
		}
		return object;

	}
	protected Object readResolve() {
		return object;
	}
	@Override
	public Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException("clone is not supported");
	}
}
