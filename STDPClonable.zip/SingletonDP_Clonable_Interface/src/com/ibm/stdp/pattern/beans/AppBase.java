package com.ibm.stdp.pattern.beans;

import java.io.Serializable;

/**
 * @author rahuldigambart
 *
 *If you observe carefully clone() method is protected method in object class
 *which cannot be visible outside the class unless we override. The way do i need
 *to implement from cloneable and should throw exception in clone() method.
 *
 */
public class AppBase implements Cloneable,Serializable{
	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
}
}