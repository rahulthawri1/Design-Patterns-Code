package com.ibm.stdp.pattern.test;

import com.ibm.stdp.pattern.beans.CurrencyConverter;

/**
 * @author rahuldigambart
 * 
 * In order not to allow singleton class to be cloneable from created objects,
 * it is even recommended to implement your class from cloneable interface
 * and override clone() method. Inside this method we should throw 
 * CloneNotSupportedException to avoid cloning of the object.
 */
public class STDPTest {

	public static void main(String[] args) throws CloneNotSupportedException {
		CurrencyConverter currencyConverter1=CurrencyConverter.getObject();
		CurrencyConverter currencyConverter2=(CurrencyConverter) currencyConverter1.clone();
		System.out.println("currencyConverter1 : " + currencyConverter1.hashCode() + " currencyConverter2 : "
				+ currencyConverter2.hashCode());
		System.out.println(currencyConverter1.equals(currencyConverter2));
		System.out.println(currencyConverter1.hashCode());
		System.out.println(currencyConverter2.hashCode());
	}

}
