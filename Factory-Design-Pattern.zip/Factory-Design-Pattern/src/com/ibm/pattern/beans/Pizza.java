package com.ibm.pattern.beans;

/**
 * @author rahuldigambart
 *
 *         Not all objects in java can be created out of new operator. Few
 *         objects may be created out of new; few may have to be created by
 *         calling a static factory method on the class (singleton) others may
 *         have to be created by passing other object as reference while
 *         creating etc.
 * 
 *         The main advantage of going for factories is it abstract the creation
 *         process of other class.
 * 
 *         For e.g let's take an example of JDBC, connection is an interface in
 *         JDBC api, respective vendor drivers will have the implementation of
 *         connection interface. Oracle driver will provide an implementation
 *         class for connection and MYSql server will provides it's own
 *         implementation for connection interface.
 */
public interface Pizza {

	public void prepare();

	public void bake();

	public void cut();

	public void box();

}
