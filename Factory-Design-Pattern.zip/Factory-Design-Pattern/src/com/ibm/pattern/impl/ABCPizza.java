package com.ibm.pattern.impl;

import com.ibm.pattern.beans.Pizza;

public class ABCPizza implements Pizza {
	@Override
	public void prepare() {
		// TODO Auto-generated method stub
		System.out.println("Preparing abc Pizza");
	}

	@Override
	public void bake() {
		// TODO Auto-generated method stub
		System.out.println("Baking abc Pizza");
	}

	@Override
	public void cut() {
		// TODO Auto-generated method stub
		System.out.println("Cutting abc Pizza");
	}

	@Override
	public void box() {
		// TODO Auto-generated method stub
		System.out.println("Packing abc Pizza");
	}
}
