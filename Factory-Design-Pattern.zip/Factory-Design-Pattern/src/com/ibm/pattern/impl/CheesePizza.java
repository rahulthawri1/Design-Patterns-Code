package com.ibm.pattern.impl;

import com.ibm.pattern.beans.Pizza;

/**
 * @author rahuldigambart
 *
 */
public class CheesePizza implements Pizza {

	@Override
	public void prepare() {
		// TODO Auto-generated method stub
		System.out.println("Preparing Cheese Pizza");
	}

	@Override
	public void bake() {
		// TODO Auto-generated method stub
		System.out.println("Baking Cheese Pizza");
	}

	@Override
	public void cut() {
		// TODO Auto-generated method stub
		System.out.println("Cutting Cheese Pizza");
	}

	@Override
	public void box() {
		// TODO Auto-generated method stub
		System.out.println("Packing Cheese Pizza");
	}
	

	

}
