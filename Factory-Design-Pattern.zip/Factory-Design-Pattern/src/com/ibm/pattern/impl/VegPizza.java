package com.ibm.pattern.impl;

import com.ibm.pattern.beans.Pizza;

public class VegPizza implements Pizza{

	@Override
	public void prepare() {
		// TODO Auto-generated method stub
		System.out.println("Preparing Veg Pizza");
	}

	@Override
	public void bake() {
		// TODO Auto-generated method stub
		System.out.println("Baking Veg Pizza");
	}

	@Override
	public void cut() {
		// TODO Auto-generated method stub
		System.out.println("Cutting Veg Pizza");
	}

	@Override
	public void box() {
		// TODO Auto-generated method stub
		System.out.println("Packing Veg Pizza");
	}

}
