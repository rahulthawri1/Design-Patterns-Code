package com.ibm.pattern.factory;

import com.ibm.pattern.beans.Pizza;
import com.ibm.pattern.impl.ABCPizza;
import com.ibm.pattern.impl.CheesePizza;
import com.ibm.pattern.impl.ChickenPizza;
import com.ibm.pattern.impl.SpicyPizza;
import com.ibm.pattern.impl.VegPizza;

/**
 * @author rahuldigambart
 *
 *
 *         Instead of writing the logic for creating various types of pizza's in
 *         PizzaStore class we can separate it and write in a factory class
 *         called PizzaFactory. Now if PizzaStore wants a pizza, it dosen't need
 *         to know which is the implementation class for creating a pizza rather
 *         it can call a factory method on the PizzaFactory class to get a pizza
 *         as shown below
 */
public class PizzaFactory {
	public static Pizza orderPizza(String type) {
		Pizza pizza = null;
		if (type.equals("cheese")) {
			pizza = new CheesePizza();
		} else if (type.equals("spicy")) {
			pizza = new SpicyPizza();
		} else if (type.equals("veg")) {
			pizza = new VegPizza();
		} else if (type.equals("chicken")) {
			pizza = new ChickenPizza();
		}else if (type.equals("abc")) {
			pizza = new ABCPizza();
		}
		return pizza;

	}
}
