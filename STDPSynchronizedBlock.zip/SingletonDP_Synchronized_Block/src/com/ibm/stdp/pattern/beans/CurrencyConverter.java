package com.ibm.stdp.pattern.beans;

/**
 * @author rahuldigambart
 *
 * Instead of making the whole method as synchronized, it is enough to enclose
 * only the conditional check in synchronized block.
 */
public class CurrencyConverter {
	// declare a static member of the same class-type in the class
	private static CurrencyConverter object;
	// construct id declared as private
	private CurrencyConverter() {

	}
	// declare a synchronized block static method level to crate only one instance
		//when in comes to multi-threaded env (static factory method)
	public  static CurrencyConverter getObject() {

		 synchronized(CurrencyConverter.class){
			if (object == null) {
				object = new CurrencyConverter();
			}
		}
		return object;

	}
}
