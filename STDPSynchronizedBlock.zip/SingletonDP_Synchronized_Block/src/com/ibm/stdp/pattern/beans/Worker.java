package com.ibm.stdp.pattern.beans;

/**
 * @author rahuldigambart
 *
 */
public class Worker implements Runnable{

	@Override
	public void run() {
		CurrencyConverter currencyConverter=CurrencyConverter.getObject();
		System.out.println("Hash-Code:"+currencyConverter.hashCode());
		
	}

}
