package com.ibm.ttdp.pattern.test;

import com.ibm.ttdp.pattern.beans.Worker;

/**
 * @author rahuldigambart
 *
 */
public class TTDPTest {

	public static void main(String[] args) {
		Worker worker = new Worker();
		for (int i = 0; i < 10; i++) {
			Thread thread1 = new Thread(worker);
			Thread thread2 = new Thread(worker);
			thread1.start();
			thread2.start();

	}

}
}
