package com.ibm.ttdp.pattern.beans;

/**
 * @author rahuldigambart
 *
 */
public class CurrencyConverter {
private static volatile int codObject;
private static CurrencyConverter object;
private CurrencyConverter()
{
	//no code
}
public static CurrencyConverter getObject()
{
	if(codObject<2)
	{
		System.out.println("locking...!!!");
		// here synchronized block
		 {
			if(codObject<=2)
			{
				System.out.println("Object Created...!!!");
				object=new CurrencyConverter();
				codObject++;
			}
		}
	}
	return object;
}
}
