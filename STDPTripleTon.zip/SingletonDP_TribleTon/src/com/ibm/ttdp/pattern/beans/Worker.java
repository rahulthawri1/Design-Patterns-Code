package com.ibm.ttdp.pattern.beans;

import com.ibm.ttdp.pattern.beans.CurrencyConverter;

/**
 * @author rahuldigambart
 *
 */
public class Worker implements Runnable{

	@Override
	public void run() {
		CurrencyConverter currencyConverter=CurrencyConverter.getObject();
		System.out.println("Hash-Code:"+currencyConverter.hashCode());
		
	}
}
